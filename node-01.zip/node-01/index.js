const express = require('express');
const app = express();
app.use(express.json());
const PORT = 3000;

//1
app.listen(PORT, () => {
    console.log(' A aplicação EXODUS está rodando na porta ' + PORT);
});

//2
let minhasNotas = [20, 10, 15, 17];

//3.a
app.get('/', (req, res) => {
    res.status(200).json(minhasNotas);
});
//3.b
app.get('/:posicao', (req, res) => {
    const posicao = parseInt(req.params.posicao);
    if(posicao >= 0 && posicao < minhasNotas.length){
        res.status(200).json(minhasNotas[posicao]);
        
    } else {
        res.status(400).json({error: 'posicao invalida'});
    }
});

//3.c
app.post('/', (req, res) => {
    if (req.body && req.body.valor !== undefined) {
        const valor = parseInt(req.body.valor);
        minhasNotas.push(valor);
        res.status(200).json(minhasNotas);
    } else {
        res.status(400).json({ error: 'Envie um JSON com { "valor": número }' });
    }
});

//3.d
app.post('/:valor', (req, res) => {
    const valor = parseInt(req.params.valor);
    minhasNotas.push(valor);
    res.status(200).json(minhasNotas);
});

//3.e

app.patch('/:posicao', (req,res) => {
    const posicao = parseInt(req.params.posicao);
    if(posicao => 0  && posicao < minhasNotas.length && req.body.valor !== undefined){
        minhasNotas[posicao] = parseInt(req.body.valor);
        res.status(200).json(minhasNotas);
    } else {
        res.status(400).json({ error: 'Posicao invalida ou valor faltando'});
    }
});
//3.f
app.delete('/:posicao', (req, res) => {
    const posicao = parseInt(req.params.posicao);
    if(posicao => 0 && posicao < minhasNotas.length){
        minhasNotas.splice(posicao, 1);
        res.status(200).json(minhasNotas);
    } else {
        res.status(400).json({error : 'posicao invalida'});
    }
});
//3.g
app.delete('/', (req, res) => {
    minhasNotas = [];
    res.status(200).json(minhasNotas);
});



