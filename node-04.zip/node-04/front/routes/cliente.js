const express = require('express');
const router = express.Router();

// Dados 
let dadosCliente = {
    "clienteld": "12345",
    "nome": "João Silva",
    "endereco": {
      "rua": "Rua Exemplo",
      "numero": "42",
      "cidade": "Lisboa",
      "codigoPostal": "1234-567"
    },
    "consumo": [
      {
        "mes": "Janeiro",
        "ano": 2023,
        "kWhConsumido": 250,
        "custoTotal": 35.50,
        "dataLeitura": "2023-01-31"
      }
    ],
    "informacoesAdicionais": {
      "tipoTarifa": "Residencial",
      "fornecedorEnergia": "Empresa XYZ",
      "contratoAtivo": true
    }
  };



router.get('/', (req, res) => {
    res.status(200).json(dadosCliente);
});


router.post('/', (req, res) => {
    if (!req.body.nome) {
        return res.status(400).json({ message: 'O campo nome é obrigatório' });
    }
    
    dadosCliente = req.body;
    res.status(200).json({ message: 'Dados Atualizados!' });
});

// Rota para lidar com parâmetros inválidos
router.get('/:id', (req, res) => {
    if (req.params.id === 'OLA') {
        return res.status(400).json({ message: 'Parâmetro inválido' });
    }
    res.status(200).json(dadosCliente);
});

// Export do router
module.exports = router;