const express = require('express');
const router = express.Router();
const Nota = require('../models/notas');

// Criar uma nova nota
router.post('/', async (req, res) => {
  try {
    const nota = new Nota(req.body);
    await nota.save();
    res.status(201).json(nota);
  } catch (error) {
    if (error.name === 'ValidationError') {
      res.status(400).json({ erro: error.message });
    } else {
      res.status(500).json({ erro: 'Erro ao criar nota' });
    }
  }
});

// Listar todas as notas
router.get('/', async (req, res) => {
  try {
    const notas = await Nota.find();
    res.json(notas);
  } catch (error) {
    res.status(500).json({ erro: 'Erro ao buscar notas' });
  }
});

// Obter uma nota específica por código da disciplina
router.get('/:codigo', async (req, res) => {
  try {
    const nota = await Nota.findOne({ codigoDisciplina: req.params.codigo });
    if (!nota) return res.status(404).json({ mensagem: 'Nota não encontrada' });
    res.json(nota);
  } catch (error) {
    res.status(500).json({ erro: 'Erro ao buscar nota' });
  }
});

// Atualizar uma nota
router.put('/:codigo', async (req, res) => {
  try {
    const nota = await Nota.findOneAndUpdate(
      { codigoDisciplina: req.params.codigo },
      req.body,
      { new: true, runValidators: true }
    );
    if (!nota) return res.status(404).json({ mensagem: 'Nota não encontrada' });
    res.json(nota);
  } catch (error) {
    if (error.name === 'ValidationError') {
      res.status(400).json({ erro: error.message });
    } else {
      res.status(500).json({ erro: 'Erro ao atualizar nota' });
    }
  }
});

// Eliminar uma nota
router.delete('/:codigo', async (req, res) => {
  try {
    const nota = await Nota.findOneAndDelete({ codigoDisciplina: req.params.codigo });
    if (!nota) return res.status(404).json({ mensagem: 'Nota não encontrada' });
    res.json({ mensagem: 'Nota eliminada com sucesso' });
  } catch (error) {
    res.status(500).json({ erro: 'Erro ao eliminar nota' });
  }
});

module.exports = router;
