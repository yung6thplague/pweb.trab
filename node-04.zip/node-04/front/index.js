document.addEventListener('DOMContentLoaded', () => {
    const btnCarregar = document.getElementById('btnCarregar');
    const btnAtualizar = document.getElementById('btnAtualizar');
    const jsonInput = document.getElementById('jsonInput');
    const dadosCliente = document.getElementById('dadosCliente');
    const jsonOutput = document.getElementById('jsonOutput');

    // Função para formatar e exibir os dados
    function displayData(data) {
        // Exibição formatada
        let html = `
            <h3>${data.nome}</h3>
            <p><strong>ID:</strong> ${data.clienteld}</p>
            <p><strong>Endereço:</strong> ${data.endereco.rua}, ${data.endereco.numero}, ${data.endereco.cidade}</p>
            <p><strong>Consumo:</strong> ${data.consumo[0].kWhConsumido} kWh (${data.consumo[0].mes}/${data.consumo[0].ano})</p>
        `;
        dadosCliente.innerHTML = html;
        
        // Exibição do JSON completo
        jsonOutput.textContent = JSON.stringify(data, null, 2);
    }

    // Carregar dados do servidor
    btnCarregar.addEventListener('click', async () => {
        try {
            const response = await fetch('http://localhost:3000/api/cliente');
            const data = await response.json();
            displayData(data);
            jsonInput.value = JSON.stringify(data, null, 2);
        } catch (error) {
            alert('Erro ao carregar dados: ' + error.message);
        }
    });

    // Atualizar dados no servidor
    btnAtualizar.addEventListener('click', async () => {
        try {
            const jsonData = JSON.parse(jsonInput.value);
            const response = await fetch('http://localhost:3000/api/cliente', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(jsonData)
            });
            const result = await response.json();
            alert(result.message);
        } catch (error) {
            alert('JSON inválido ou erro no servidor: ' + error.message);
        }
    });
});