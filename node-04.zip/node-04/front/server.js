const express = require('express');
const cors = require('cors');
const clienteRoutes = require('./routes/cliente'); // Nome consistente
const mongoose = require('mongoose');
const app = express();
const notasRouter = require('./routes/notas');

app.use('/api/notas', notasRouter);
app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://localhost:27017/notasApp', {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log('Conectado ao MongoDB'))
.catch(err => console.error('Erro na conexão com MongoDB:', err));

//middleware
app.use((req, res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
    next();
});

// routes
app.use('/api/cliente', clienteRoutes); // Usando o mesmo nome

// 404 
app.use((req, res) => {
    res.status(404).json({ message: 'Endpoint não encontrado' });
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});