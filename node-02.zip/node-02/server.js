const express = require('express');
const app = express();
const cors = require('cors');

app.use(cors());
app.use(express.json());

//dados
let dadosCliente = {
    "clienteld": "12345",
    "nome": "João Silva",
    "endereco": {
      "rua": "Rua Exemplo",
      "numero": "42",
      "cidade": "Lisboa",
      "codigoPostal": "1234-567"
    },
    "consumo": [
      {
        "mes": "Janeiro",
        "ano": 2023,
        "kWhConsumido": 250,
        "custoTotal": 35.50,
        "dataLeitura": "2023-01-31"
      }
    ],
    "informacoesAdicionais": {
      "tipoTarifa": "Residencial",
      "fornecedorEnergia": "Empresa XYZ",
      "contratoAtivo": true
    }
  };

  app.get('/api/cliente', (req, res) => {
    res.status(200).json(dadosCliente);
  });

  app.post('/api/cliente', (req, res) => {
    dadosCliente = req.body;
    res.status(200).json({message: 'Dados Atualizados!'});
  });

  const PORT = 3000;
  app.listen(PORT, () => {
    console.log('Server running at http://localhost:${PORT}');
  });
